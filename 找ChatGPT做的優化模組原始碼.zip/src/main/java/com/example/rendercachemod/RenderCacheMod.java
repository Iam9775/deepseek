package com.example.rendercachemod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.nio.IntBuffer;

@Mod("rendercachemod")
public class RenderCacheMod {
    private final Minecraft mc = Minecraft.getInstance();

    private DynamicTexture cachedTexture;
    private ResourceLocation cachedTextureLocation;
    private int width, height;
    private boolean needsUpdate = true;
    private int[] pixels;

    private long lastUpdateTime = 0;
    private static final long UPDATE_INTERVAL_MS = 1000; // 每秒更新一次
    private double lastPlayerX, lastPlayerZ;

    public RenderCacheMod() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (mc.level == null || mc.player == null) return;

        // 玩家位置改變超過閾值，標記需要更新快取
        double dx = mc.player.getX() - lastPlayerX;
        double dz = mc.player.getZ() - lastPlayerZ;
        double distSq = dx * dx + dz * dz;

        long now = System.currentTimeMillis();
        if (distSq > 0.01 || now - lastUpdateTime > UPDATE_INTERVAL_MS) {
            needsUpdate = true;
            lastPlayerX = mc.player.getX();
            lastPlayerZ = mc.player.getZ();
            lastUpdateTime = now;
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (mc.level == null || mc.player == null) return;

        width = mc.getWindow().getWidth();
        height = mc.getWindow().getHeight();

        if (!needsUpdate && cachedTextureLocation != null) {
            // 用快取貼圖快速渲染畫面
            RenderSystem.enableBlend();
            mc.getTextureManager().bindForSetup(cachedTextureLocation);
            blitFullScreen();
            RenderSystem.disableBlend();

            event.setCanceled(true); // 取消原本渲染
            return;
        }

        // 需要更新快取，擷取 framebuffer
        if (pixels == null || pixels.length != width * height) {
            pixels = new int[width * height];
        }

        IntBuffer buffer = IntBuffer.wrap(pixels);
        buffer.position(0);

        // 讀取 framebuffer pixels
        RenderSystem.bindTexture(0);
        RenderSystem.readPixels(0, 0, width, height, false, buffer);

        // 修正上下顛倒
        int[] flippedPixels = new int[pixels.length];
        for (int y = 0; y < height; y++) {
            System.arraycopy(pixels, y * width, flippedPixels, (height - y - 1) * width, width);
        }

        if (cachedTexture == null) {
            cachedTexture = new DynamicTexture(width, height, false);
            cachedTextureLocation = mc.getTextureManager().register("rendercachemod/cache", cachedTexture);
        }

        cachedTexture.getPixels().setData(flippedPixels);
        cachedTexture.upload();

        needsUpdate = false;

        // 直接渲染快取貼圖
        RenderSystem.enableBlend();
        mc.getTextureManager().bindForSetup(cachedTextureLocation);
        blitFullScreen();
        RenderSystem.disableBlend();

        event.setCanceled(true);
    }

    private void blitFullScreen() {
        net.minecraft.client.gui.GuiComponent.blit(0, 0, width, height, 0, 0, 1, 1, 1, 1);
    }
}
