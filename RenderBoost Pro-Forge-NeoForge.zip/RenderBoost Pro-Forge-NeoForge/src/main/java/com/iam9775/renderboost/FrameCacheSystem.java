package com.example.renderboost;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class FrameCacheSystem {
    private static final Map<Integer, CachedFrame> FRAME_CACHE = new HashMap<>();
    private static int currentHash = 0;
    
    public static void cacheFrame(BufferedImage image) {
        int hash = calculateImageHash(image);
        FRAME_CACHE.put(hash, new CachedFrame(image, System.currentTimeMillis()));
        currentHash = hash;
    }
    
    public static BufferedImage getCachedFrame(int hash) {
        CachedFrame cached = FRAME_CACHE.get(hash);
        return cached != null ? cached.image() : null;
    }
    
    public static int getCurrentHash() {
        return currentHash;
    }
    
    private static int calculateImageHash(BufferedImage image) {
        // 簡化的哈希計算
        return image.getWidth() + image.getHeight();
    }
    
    private record CachedFrame(BufferedImage image, long timestamp) {}
}
