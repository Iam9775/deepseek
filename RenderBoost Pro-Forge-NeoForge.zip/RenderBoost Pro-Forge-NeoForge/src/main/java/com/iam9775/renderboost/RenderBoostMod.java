package com.iam9775.renderboost;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.common.NeoForge;

@Mod("renderboost")
public class RenderBoostMod {
    public static final String MOD_ID = "renderboost";
    private static RenderBoostMod INSTANCE;
    
    public RenderBoostMod() {
        INSTANCE = this;
        
        // 自動檢測並註冊正確的事件總線
        if (PlatformUtil.isNeoForge()) {
            NeoForge.EVENT_BUS.register(this);
        } else {
            net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
        }
        
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
    }
    
    private void setup(final net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
        // 初始化模組
        FrameCacheSystem.initialize();
        PerformanceMonitor.start();
    }
    
    public static RenderBoostMod getInstance() {
        return INSTANCE;
    }
}
