// RenderDecisionEngine.java
// Auto-generated on 2025-06-24T08:30:37.508446